//
//  Scanner.swift
//  VirtualMenu
//
//  Created by Rohan Tyagi on 5/31/20.
//  Copyright © 2020 Rohan Tyagi. All rights reserved.
//

import Foundation
import SwiftUI

struct Scanner : View {
    var request: VNRecognizeTextRequest!
    // Temporal string tracker
    var promptLabel: UILabel!
    let numberTracker = StringTracker()
    var dishName: String?
    
    var body: some View {
        
        
        
        
    }
    
    
}
