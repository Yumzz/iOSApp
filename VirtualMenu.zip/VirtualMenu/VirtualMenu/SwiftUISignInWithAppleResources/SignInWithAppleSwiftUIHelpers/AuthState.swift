//
//  AuthState.swift
//  SwiftUISignInWithApple
//
//  Created by Alex Nagy on 04/11/2019.
//  Copyright © 2019 Alex Nagy. All rights reserved.
//

import Foundation

enum AuthState {
    case undefined, signedOut, signedIn
}
