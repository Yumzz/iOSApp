//
//  XButtonDelete.swift
//  VirtualMenu
//
//  Created by Rohan Tyagi on 10/16/20.
//  Copyright © 2020 Rohan Tyagi. All rights reserved.
//

import Foundation
import SwiftUI

struct XButtonDelete: View {

    var body: some View {
        
        HStack{
                Image("x_button")

        }
    }
}
