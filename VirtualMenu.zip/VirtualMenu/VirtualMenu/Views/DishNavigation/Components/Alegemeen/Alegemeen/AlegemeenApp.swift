//
//  AlegemeenApp.swift
//  Alegemeen
//
//  Created by Rohan Tyagi on 3/5/21.
//

import SwiftUI

@main
struct AlegemeenApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
