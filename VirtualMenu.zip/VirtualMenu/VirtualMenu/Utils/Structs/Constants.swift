//
//  Constants.swift
//  VirtualMenu
//
//  Created by Rohan Tyagi on 7/6/20.
//  Copyright © 2020 Rohan Tyagi. All rights reserved.
//

import Foundation

struct Constants {
    
    struct baseURL {
        static let api = "https://us-central1-virtual-menu-59b9e.cloudfunctions.net"
    }
}

